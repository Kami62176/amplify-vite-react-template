import { createTheme } from "@mui/material/styles";
import { red } from "@mui/material/colors";

declare module '@mui/material/styles' {
    interface Palette {
        logout: Palette['primary'],
        white: Palette['primary']
    }
    interface PaletteOptions {
        logout?: PaletteOptions['primary']
        white?: PaletteOptions['primary']
    }
}
declare module '@mui/material/IconButton' {
    interface IconButtonPropsColorOverrides {
      logout: true;
      white: true;
    }
  }

const theme = createTheme({
    palette: {
        primary: {
            main: '#2b2b3d'
        },
        secondary: {
            main: '#1A1A28'
        },
        logout: {
            main: red[900],
            light: '#fff',
            dark: "#7F000F",
            contrastText: "#fff"
        },
        white: {
            main: "#fff"
        }
    }
})

export default theme