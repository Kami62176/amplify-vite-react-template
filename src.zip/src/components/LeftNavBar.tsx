import { IconButton } from "@mui/material";
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import { useNavigate } from "react-router-dom";

export default function () {
    const navigate = useNavigate();
    return (
        <div className="sidebar left">
            <IconButton color="white" onClick={() => navigate('./strategy')}>
                <TrendingUpIcon />
            </IconButton>
        </div>
    )
}