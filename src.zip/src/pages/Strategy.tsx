import { Typography } from "@mui/material";


export default function() {
    return (
        <>
            <Typography variant="h1">WHATS THE WORD?!</Typography>
        </>
    )
}